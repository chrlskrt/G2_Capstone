package WordlePackage;

public class MainPage {
    public static void main(String[] args) {
        WordleGUI wg = new WordleGUI();
        wg.displaywelcome();
    }
}
